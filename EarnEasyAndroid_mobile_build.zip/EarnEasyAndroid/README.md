# EarnEasy Android starter

A native Android starter project using Kotlin and Jetpack Compose.

## Run
1. Install Android Studio.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Run on an Android emulator or connected Android device.

## Included
- Home, Tasks and Wallet screens
- Four sample tasks
- Local demo task-submission state

## Not yet implemented
Phone-number OTP login, permanent user IDs, cloud database, admin review, AdMob, cash payouts and Play Store publishing. The displayed points are demo-only and have no cash value.

Before publishing, add secure backend services, privacy disclosures, task verification and moderation, fraud prevention, support details, and policy-compliant ads and payments. Check current Google Play and local legal requirements.
